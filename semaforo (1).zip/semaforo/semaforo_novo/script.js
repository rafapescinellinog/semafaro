let intervalo; // guarda o ciclo automático
let indice = 0; // posição no ciclo
const cores = ["verde", "amarelo", "vermelho"];

function acender(cor) {
  apagar();
  document.getElementById(cor).classList.add('acesa');
}

function apagar() {
  const luzes = document.querySelectorAll('.luz');
  luzes.forEach(luz => luz.classList.remove('acesa'));
}

function automatico() {
  parar(); // garante que não cria vários ciclos
  indice = 0;
  acender(cores[indice]);

  intervalo = setInterval(() => {
    indice = (indice + 1) % cores.length;
    acender(cores[indice]);
  }, 2000); // muda a cada 2 segundos
}

function parar() {
  clearInterval(intervalo);
}
